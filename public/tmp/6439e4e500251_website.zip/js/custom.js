
var pAgree = '1';
